

users

for number in range(10):
    rooms.append(Room("Asshole" + str(number), ))
    print("Room Name: " + rooms[number].getName() + "\tPassWord: " + rooms[number].getPassW())
    

for (roomName, roomPass) in rooms()



for n in range(len(rooms)):
    if rooms[n].getName() == "Asshole0":
        rooms.remove(rooms[n])
        break

